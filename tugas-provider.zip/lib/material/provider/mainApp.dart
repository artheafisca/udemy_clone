import 'package:flutter/material.dart';
import 'package:flutter_application_1/material/provider/color_shared_state.dart';
import 'package:provider/provider.dart';

class StateApp extends StatelessWidget {
  const StateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ExampleState(),
    );
  }
}

class ExampleState extends StatefulWidget {
  const ExampleState({super.key});

  @override
  State<ExampleState> createState() => _ExampleStateState();
}

class _ExampleStateState extends State<ExampleState> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ColorState>(
      create: (context) => ColorState(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.grey[900],
          title: Consumer<ColorState>(
            builder: (context, colorstate, child) => Text(
              "State Management",
              style: TextStyle(color: colorstate.getColor),
            ),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Text Tidak Berganti"),
              SizedBox(
                height: 10,
              ),
              Consumer<ColorState>(
                builder: (context, colorsate, child) => Container(
                  height: 150,
                  width: 150,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: colorsate.getColor),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Deep Purple"),
                  Consumer<ColorState>(
                    builder: (context, colorstate, child) => Switch(
                      value: colorstate.getIsOrange,
                      onChanged: (value) {
                        colorstate.setColor = value;
                      },
                    ),
                  ),
                  Text("Deep Orange")
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
