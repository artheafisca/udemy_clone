import 'package:flutter/material.dart';
import 'package:flutter_application_1/material/22_InWell.dart';
import 'package:flutter_application_1/material/23_opacity.dart';

void main() {
  runApp(LatihanOpacity());
}
